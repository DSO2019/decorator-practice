class User():

    def __init__(self, username):
        self.username = username

    def getUsername(self):
        return self.username

    def aprove(self):
        pass
    
    def comment(self):
        pass
    
    def delete(self):
        pass

    def publish(self):
        pass
 